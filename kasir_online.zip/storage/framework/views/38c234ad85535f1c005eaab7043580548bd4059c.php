<div id="app">
  <div style="text-align: center;" class="modal fade" id="modal-edit<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document" style="width: 900px">
     <div class="modal-content">
      <div class="full-page invoice-page section-image" filter-color="black" data-image="../../assets/img/bg13.jpg">
        <div class="content">
          <div class="container">

            <div class="row">
              <div class="col-12 text-right">
                <a id="modal-edit<?php echo e($row->id); ?>" href="<?php echo e(route('order.show', $row->id)); ?>" target="_blank" href=""><button type="button" name="button" class="btn btn-primary btn-round btn-sm">Download</button></a>
              </div>
            </div>
            <!--   <a id="modal-edit<?php echo e($row->id); ?>" href="<?php echo e(route('order.show', $row->id)); ?>" target="_blank" class="btn btn-default btn-sm pull-left"><i class="fa fa-print"></i> Cetak</a> -->
            <div class="row">
              <div class="col-12">
                <h4 class="card-title">Invoice <span class="font-weight-light">#<?php echo e($row->table_number); ?></span></h4>
                <h5 class="card-description mt-3 font-weight-bold">
                  <hr> Toko Besi 
                </h5>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-12">
                <div class="table-responsive">
                  <table class="table mt-3">
                    <thead>
                      <tr>
                        <th class="pl-0">
                          <h6 class="font-weight-bold text-capitalize">No</h6>
                        </th>
                        <th class="px-0 ">
                          <h6 class="font-weight-bold text-capitalize">Pesanan</h6>
                        </th>
                        <th class="pr-0 text-center">
                          <h6 class="font-weight-bold text-capitalize">Catatan</h6>
                        </th>
                        <th class="pr-0 text-center">
                          <h6 class="font-weight-bold text-capitalize">Price</h6>
                        </th>
                        <th class="pr-0 text-center">
                          <h6 class="font-weight-bold text-capitalize">Jumlah</h6>
                        </th>
                        <th class="pr-0 text-center">
                          <h6 class="font-weight-bold text-capitalize">Subtotal</h6>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $no = 1;
                      ?>
                      <?php $__currentLoopData = $row->orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($odt->product_name); ?></td>
                        <td><?php echo e($odt->note); ?></td>
                        <td><?php echo e(rupiah($odt->product_price)); ?></td>
                        <td><?php echo e($odt->quantity); ?></td>
                        <td><?php echo e(rupiah($odt->subtotal)); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td colspan="5">Total</td>
                        <td><?php echo e(rupiah($row->orderDetail->sum('subtotal'))); ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="row mt-5">
              <div class="col-12 col-md-6">

                <h6 class="text-uppercase card-description font-weight-bold mb-3">
                  Invoiced from
                </h6>
                <p class="mb-4">
                  <strong><?php echo e($row->user->name); ?></strong> <br>
                  <?php echo e(date('d F Y', strtotime($row->created_at))); ?> <br>
                  <?php echo e(date('H:i', strtotime($row->created_at))); ?> WIB
                </p>
              </div>
              <div class="col-12 col-md-6 ">
                <h6 class="text-uppercase card-description font-weight-bold mb-3">
                  Invoiced to
                </h6>
                <p class="mb-4">
                  <strong><?php echo e($row->name); ?></strong> <br>
                  Metode Pembayaran <br>
                  <?php echo e($row->payment->name); ?>

                </p>
              </div>
            </div>
          </div>
          <hr class="hr">
          <div class="card-footer text-center">

            <form method="post" action="<?php echo e(route('order.mail', $row->id)); ?>">
              <?php echo csrf_field(); ?>
         <!--      <a href="<?php echo e(route('order.show', $row->id)); ?>" target="_blank" class="btn btn-default btn-sm pull-left"><i class="fa fa-print"></i> Cetak</a>
              <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-send"></i> Kirim via Email</button>
              <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal"><i class="fa fa-remove"></i> Tutup</button> -->
              <button type="submit" class="btn btn-primary btn-round w-50 mt-3" name="button">Kirim Email</button>
            </form>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
</div>
</div>

<?php /**PATH /home/u1548361/public_html/ko/resources/views/backend/admin/order/modal.blade.php ENDPATH**/ ?>