
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="card ">
  <div class="card-header ">
    <h4 class="card-title"><?php echo e($title); ?></h4>
  </div>
  <div class="card-body ">
    <form method="post" method="post" action="<?php echo e(route('item.update', $data->id)); ?>" class="form-horizontal">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="row">
        <label class="col-md-3 col-form-label">Kategori</label>
        <div class="col-md-9">
          <div class="form-group">
            <select class="form-control" required="" name="category">
              <option value=""> -- Silahkan Pilih Kategori -- </option>
              <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option class="form-control" value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Nama</label>
        <div class="col-md-9">
          <div class="form-group">
            <input type="text" name="name" value="<?php echo e($data->name); ?>" class="form-control" required="">
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Merk</label>
        <div class="col-md-9">
          <div class="form-group">
            <input type="text" name="merk"  value="<?php echo e($data->merk); ?>" class="form-control" required="">
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Harga Beli</label>
        <div class="col-md-3">
          <div class="form-group">
            <input type="text" name="purchase_price"  value="<?php echo e($data->purchase_price); ?>" class="form-control" required="">
          </div>
        </div>
        <label class="col-md-3 col-form-label">Harga Jual</label>
        <div class="col-md-3">
          <div class="form-group">
            <input type="text" name="price"  value="<?php echo e($data->price); ?>" class="form-control" required="">
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Stock</label>
        <div class="col-md-3">
          <div class="form-group">
            <input type="text" name="stock"  value="<?php echo e($data->stock); ?>" class="form-control" required="">
          </div>
        </div>
        <label class="col-md-3 col-form-label">Stock Minim</label>
        <div class="col-md-3">
          <div class="form-group">
            <input type="text" name="stock_minim"  value="<?php echo e($data->stock_minim); ?>" class="form-control" required="">
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Status</label>
        <div class="form-group">
          <div class="form-check form-check-radio">
            <label class="form-check-label">
              <input name="status" value="1" class="form-check-input" type="radio" name="exampleRadio" id="exampleRadios3" value="option1">
              <span class="form-check-sign"></span>
              Ada
            </label>
            <label class="form-check-label">
              <input  name="status" value="0"  class="form-check-input" type="radio" name="exampleRadio" id="exampleRadios3" value="option1">
              <span class="form-check-sign"></span>
              Tidak Ada
            </label>
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Cabang Toko</label>
        <div class="col-md-9">
          <div class="form-group">
           <select name="nama_cabang" class="form-control" required="">
            <option value=""> -- Silahkan Pilih Cabang -- </option>
            <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option class="form-control" value="<?php echo e($row->nama_cabang); ?>"><?php echo e($row->nama_cabang); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-md-3"></label>
      <div class="col-md-9">
        <div class="form-check">
          <label class="form-check-label">
            <input class="form-check-input" type="checkbox">
            <span class="form-check-sign"></span>
            Ingatkan Saya 
          </label>
        </div>
      </div>
    </div>
  </div>
  <div class="card-footer ">
    <div class="row">
      <label class="col-md-3"></label>
      <div class="col-md-9">
        <button type="reset" class="btn btn-fill btn-danger">Reset</button>
        <button type="submit" class="btn btn-fill btn-success">Masuk</button>
      </div>
    </div>
  </div>
</form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/produk/edit.blade.php ENDPATH**/ ?>