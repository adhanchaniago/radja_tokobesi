<footer class="footer">
  <div class=" container-fluid ">
    <nav>
      <ul>
        <li>
          <a href="https://www.creative-tim.com">
           Toko Besi
         </a>
       </li>
       <li>Support by
        <a href="http://presentation.creative-tim.com">
          <b>creative tim</b>
        </a>
      </li>
    </ul>
  </nav>
  <div class="copyright" id="copyright">
    &copy; <script>
      document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
    </script>, Designed by <a href="https://www.invisionapp.com" target="_blank">Invision</a>. Coded by <a href="https://radjaadvertising.com/" target="_blank">Radja Digital Creative</a>.
  </div>
</div>
</footer>