
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"><?php echo e($title); ?></h4>
        <!-- Example split danger button -->
        <div  class="btn-group">
        </button>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Separated link</a>
        </div>
      </div>
    </div>
    <div class="card-body">
      <div class="toolbar">
      </div>
      <table id="table-datatables" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
          <tr>
            <th>No</th>
            <th>Nomor Pelanggan</th>
            <th>Pembayaran</th>
            <th>Kasir</th>
            <!-- <th>Cabang</th> -->
            <th>Total</th>
            <th>Tanggal</th>
            <th class="disabled-sorting text-right">Actions</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            <th colspan="4" class="text-center">Total</th>
            <!-- <th>Cabang</th> -->
            <th>Total</th>
            <th>Tanggal</th>
            <th class="disabled-sorting text-center">Actions</th>
          </tr>
        </tfoot>
        <tbody>
          <?php
          $nomor = 1;
          function rupiah($m)
          {
            $rupiah = "Rp ".number_format($m,0,",",".");
            return $rupiah;
          }
          ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($row->keperluan == 'Penjualan'): ?>
          <tr>
           <td><?php echo e($nomor++); ?></td>
           <td><?php echo e($row->table_number); ?></td>
           <td><?php echo e($row->payment->name); ?></td>
           <td><?php echo e($row->user->name); ?></td>
           <!-- <td><?php echo e($row->lokasi); ?></td> -->
           <td>Rp <?php echo number_format($row->total) ?></td>
           <td><?php echo e($row->created_at); ?></td>
           <td class="text-center">
            <?php echo $__env->make('backend.admin.order.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <a href="<?php echo e(url('admin/order/'.$row->id.'/edit')); ?>" data-toggle="modal" data-target="#modal-edit<?php echo e($row->id); ?>"  class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-heart"></i></a>
          </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
</div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Grade Pesanan</h4>
        <!-- Example split danger button -->
        <div  class="btn-group">
        </div>
      </div>
      <div class="card-body">
        <div class="toolbar">
        </div>
        <table id="table-datatables2" class="table table-striped table-bordered" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Produk</th>
              <th>Cabang</th>
              <th width="15%">Barang Terjual</th>
              <th>Tanggal</th>
              <!-- <th class="disabled-sorting text-right">Actions</th> -->
            </tr>
          </thead>
          <tfoot>
            <tr>
             <th>No</th>
             <th>Nama Produk</th>
             <th>Cabang</th>
             <th width="15%">Barang Terjual</th>
             <th>Tanggal</th>
             <!-- <th class="disabled-sorting text-center">Actions</th> -->
           </tr>
         </tfoot>
         <tbody>
          <?php
          $nomor = 1;
          ?>
          <?php $__currentLoopData = $terjual -> sortByDesc('terjual'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <?php if($terjual -> max('terjual') == $row->terjual): ?>
            <td bgcolor="success"><?php echo e($nomor++); ?></td>
            <td bgcolor="success"><?php echo e($row->name); ?></td>
            <td bgcolor="success"><?php echo e($row->cabang); ?></td>
            <td class="text-center" bgcolor="success"><?php echo e($row->terjual); ?></td>
            <td bgcolor="success"><?php echo e($row->created_at); ?></td>
            <?php else: ?>
            <td><?php echo e($nomor++); ?></td>
            <td><?php echo e($row->name); ?></td>
            <td><?php echo e($row->cabang); ?></td>
            <td class="text-center"><?php echo e($row->terjual); ?></td>
            <td><?php echo e($row->created_at); ?></td>
            <?php endif; ?>
            
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <h4 class="card-title">Sortir Tiap Cabang</h4>
      <!-- Example split danger button -->
      <div  class="btn-group">
      </div>
    </div>

    <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $links): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordion" id="accordionExample-<?php echo e($links->id); ?>">
      <div class="card">
        <div class="card-header" id="headingTwo">
          <h2 class="mb-0">
            <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#modal-show<?php echo e($links->id); ?>" aria-expanded="false" aria-controls="collapseTwo">
              <h6 style="font-size: 18px;"><?php echo e($links->cabang); ?></h6>
            </button>
          </h2>
        </div>
        <div id="modal-show<?php echo e($links->id); ?>" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample-<?php echo e($links->id); ?>">
          <div class="card-body">
            <table class="table table-striped table-bordered" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Produk</th>
                  <th>Cabang</th>
                  <th width="15%">Barang Terjual</th>
                  <th>Tanggal</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>No</th>
                  <th>Nama Produk</th>
                  <th>Cabang</th>
                  <th width="15%">Barang Terjual</th>
                  <th>Tanggal</th>
                </tr>

              </tfoot>
              <tbody>
                <?php
                $nomor = 1;
                ?>
                <?php $__currentLoopData = $terjual-> sortbyDesc('terjual'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($links->cabang == $row->cabang): ?>
                <tr>
                  <td><?php echo e($nomor++); ?></td>
                  <td><?php echo e($row->name); ?></td>
                  <td><?php echo e($row->cabang); ?></td>
                  <td class="text-center"><?php echo e($row->terjual); ?></td>
                  <td><?php echo e($row->created_at); ?></td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>



<?php $__env->startSection('script'); ?>
<script type="text/javascript"> 
  $(document).ready(function () {
    $('#table-datatables').DataTable({
     "scrollX": true,
     dom: 'Bfrtip',
     buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
     "footerCallback": function ( row, data, start, end, display ) {
      var api = this.api(), data;

            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
              return typeof i === 'string' ?
              i.replace(/[\Rp,]/g, '')*1 :
              typeof i === 'number' ?
              i : 0;
            };


            // Total Uang Keluar
            total2 = api
            .column( 4 )
            .data()
            .reduce( function (a, b) {
              return intVal(a) + intVal(b);
            }, 0 );

            // Total over this page
            pageTotal2 = api
            .column( 4, { page: 'current'} )
            .data()
            .reduce( function (a, b) {
              return intVal(a) + intVal(b);
            }, 0 );

            // Update footer
            $( api.column( 4 ).footer() ).html(
              'Rp '+ pageTotal2 
              );


          }
        });
  });
</script>
<script type="text/javascript"> 
  $(document).ready(function () {
    $('#table-datatables2').DataTable({
     "scrollX": true,
     dom: 'Bfrtip',
     buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
     "footerCallback": function ( row, data, start, end, display ) {
      var api = this.api(), data;

            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
              return typeof i === 'string' ?
              i.replace(/[\Rp,]/g, '')*1 :
              typeof i === 'number' ?
              i : 0;
            };


            // Total Uang Keluar
            total2 = api
            .column( 3 )
            .data()
            .reduce( function (a, b) {
              return intVal(a) + intVal(b);
            }, 0 );

            // Total over this page
            pageTotal2 = api
            .column( 3, { page: 'current'} )
            .data()
            .reduce( function (a, b) {
              return intVal(a) + intVal(b);
            }, 0 );

            // Update footer
            $( api.column( 3 ).footer() ).html(
              pageTotal2 +' Barang'
              );


          }
        });
  });
</script>
<script type="text/javascript"> 
  $(document).ready(function () {
    $('#table-datatables3').DataTable({
     "scrollX": true,
     dom: 'Bfrtip',
     buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
     "footerCallback": function ( row, data, start, end, display ) {
      var api = this.api(), data;

            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
              return typeof i === 'string' ?
              i.replace(/[\Rp,]/g, '')*1 :
              typeof i === 'number' ?
              i : 0;
            };


            // Total Uang Keluar
            total2 = api
            .column( 3 )
            .data()
            .reduce( function (a, b) {
              return intVal(a) + intVal(b);
            }, 0 );

            // Total over this page
            pageTotal2 = api
            .column( 3, { page: 'current'} )
            .data()
            .reduce( function (a, b) {
              return intVal(a) + intVal(b);
            }, 0 );

            // Update footer
            $( api.column( 3 ).footer() ).html(
              pageTotal2 +' Barang'
              );


          }
        });
  });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\RADJA WEB\kasir_online\resources\views/backend/admin/report/index.blade.php ENDPATH**/ ?>