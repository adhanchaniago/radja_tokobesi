
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"><?php echo e($title); ?></h4>
                <!-- Example split danger button -->
                <?php if(auth()->user()->level == 'Owner'): ?> 

                <div  class="btn-group">
                    <a href="<?php echo e(route('payment.create')); ?>"><button type="button" class="btn btn-success"><i class="now-ui-icons ui-1_simple-add"></i> Tambah</button></a>
                    <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#">Import CSV</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="toolbar">
                </div>
                <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Dibuat</th>
                            <th class="disabled-sorting text-right">Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Dibuat</th>
                            <th class="disabled-sorting text-right">Actions</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php
                        $nomor = 1;
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                         <td><?php echo e($nomor++); ?></td>
                         <td><?php echo e($row->name); ?></td>
                         <td><?php echo e($row->created_at); ?></td>
                         <td class="text-right">
                            <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('payment.destroy',$row->id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('delete')); ?>

                            </form>
                            <?php echo $__env->make('backend.admin.payment.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php if(auth()->user()->level == 'Owner'): ?> 

                            <a href="<?php echo e(url('admin/payment/'.$row->id.'/edit')); ?>" data-toggle="modal" data-target="#modal-edit<?php echo e($row->id); ?>"  class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-heart"></i></a>
                            <a href="<?php echo e(url('admin/payment/'.$row->id.'/edit')); ?>"  class="btn btn-round btn-warning btn-icon btn-sm edit"><i class="far fa-calendar-alt"></i></a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/payment/index.blade.php ENDPATH**/ ?>