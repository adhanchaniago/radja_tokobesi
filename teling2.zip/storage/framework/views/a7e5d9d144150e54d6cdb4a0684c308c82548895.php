
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="card ">
  <div class="card-header ">
    <h4 class="card-title"><?php echo e($title); ?></h4>
  </div>
  <div class="card-body ">
    <form method="post" method="post" action="<?php echo e(route('restock.store')); ?>" class="form-horizontal">
      <?php echo csrf_field(); ?>
      <div class="row">
        <label class="col-md-2 col-form-label">Cabang Toko</label>
        <div class="col-md-8">
          <div class="form-group">
           <select class="form-control" name="lokasi" required="">
            <option value=""> --Pilih Lokasi-- </option>
            <?php $__currentLoopData = $cab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cab->lokasi); ?>"><?php echo e($cab->lokasi); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-md-2 col-form-label">Petugas Kasir</label>
      <div class="col-md-3">
        <div class="form-group">
          <input type="text" name="name" value="<?php echo e(auth()->user()->name); ?>" class="form-control" readonly="">
        </div>
      </div>
      <label class="col-md-2 col-form-label">Tanggal Restock</label>
      <div class="col-md-3">
        <div class="form-group">
          <input type="text" name="created_at" value="<?php echo e(date('d F Y')); ?>" class="form-control" readonly="">
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-md-2 col-form-label">Supplier</label>
      <div class="col-md-3">
        <div class="form-group">
         <select class="form-control" name="supplier" required="">
          <option value=""> --Pilih Supplier-- </option>
          <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($sup->perusahaan); ?>"><?php echo e($sup->perusahaan); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>
  </div>

  <div id="app">
    <div class="row" v-for="(order, index) in orders" :key="index">
      <label class="col-md-2 col-form-label">Stock Barang</label>
      <div class="col-md-4">
        <div class="form-group">
          <select class="form-control" name="pesanan[]" v-model="order.pesanan">
            <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($mow->status): ?>
            <option value="<?php echo e($mow->id); ?>"><?php echo e($mow->name); ?></option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <input type="hidden" name="nama[]" :value="product_name(order.pesanan, index)">
          <input type="hidden" name="harga[]" :value="product_price(order.pesanan, index)">
          <input type="hidden" name="status[]" value="0"> 
        </div>
      </div>
      <label class="col-md-2 col-form-label">Jumlah</label>
      <div class="col-md-3">
        <div class="form-group">
          <input type="number" name="jumlah[]" class="form-control" value="<?php echo e(old('jumlah')); ?>" id="inputJumlah" placeholder="ex: 2" v-model="order.jumlah">
        </div>
      </div>
      <label class="col-md-2 col-form-label">Harga Beli</label>
      <div class="col-md-4">
        <div class="form-group">
         <input  type="number" name="jumlah2[]" class="form-control" value="<?php echo e(old('jumlah2')); ?>" id="inputJumlah2" placeholder="ex: 2" v-model="order.jumlah2" required="">
       </div>
     </div>

     <label class="col-md-2 col-form-label">Subtotal</label>
     <div class="col-md-3">
      <div class="form-group">
        <input  type="text" name="subtotal[]" class="form-control" readonly v-model="order.subtotal" :value="subtotal(order.jumlah2, order.jumlah, index)">
        <button type="button" class="btn btn-danger btn-sm" @click="delOrder(index)"><i class="fa fa-trash"></i></button>
        <button type="button" class="btn btn-success btn-sm" @click="addOrder()" ><i class="fa fa-plus"></i></button>
      </div>
    </div>
  </div>
  <div class="row">

  </div><br>
  <div style="text-align: center; font-size: 24px;" class="row">
   <div class="col-md-12">
    <input type="hidden" name="discount" class="form-control" v-model="discount" required="">
    <input type="hidden" name="total" :value="total" readonly="">
    <b>Total Rp {{rupiah(total)}}</b>
  </div>
</div>
</div>

</div><br>
<div class="card-footer ">
  <div class="row">
    <label class="col-md-3"></label>
    <div class="col-md-9">
      <button type="reset" class="btn btn-fill btn-danger">Reset</button>
      <button type="submit" class="btn btn-fill btn-success">Masuk</button>
    </div>
  </div>
</div>
</form>

</div>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Daftar Barang Inden</h4>
        <!-- Example split danger button -->

      </div>
      <div class="card-body">
        <div class="toolbar">
        </div>
        <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
          <thead style="font-size: 11px;">
            <tr>
              <th>No</th>
              <th>Penanggung Jawab</th>
              <th>Cabang</th>
              <th>Barang</th>
              <th>Harga Beli</th>
              <th>Jumlah</th>
              <th>Total</th>
              <th>Status</th>
              <th>Input</th>
              <th class="disabled-sorting text-right">Hapus</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Penanggung Jawab</th>
              <th>Cabang</th>
              <th>Barang</th>
              <th>Harga Beli</th>
              <th>Jumlah</th>
              <th>Total</th>
              <th>Status</th>
              <th>Input</th>
              <th class="disabled-sorting text-right">Hapus</th>
            </tr>
          </tfoot>
          <tbody>
            <?php
            $nomor    = 1;
            function rupiah($m)
            {
              $rupiah = "Rp ".number_format($m,0,",",".").",-";
              return $rupiah;
            }
            ?>
            <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
            <?php if(($row->lokasi) == (auth()->user()->lokasi) && (auth()->user()->level) =='Admin'): ?>
            <tr>
              <td><?php echo e($nomor++); ?></td>
              <td><?php echo e($row->name); ?></td>
              <td><?php echo e($row->lokasi); ?></td>
              <td><?php echo e($row->product_name); ?></td>
              <td><?php echo e(rupiah($row->product_price)); ?></td>
              <td><?php echo e($row->quantity); ?> Pcs</td>
              <td><?php echo e(rupiah($row->subtotal)); ?></td>
              <?php if($row->status == 0 && auth()->user()->level == 'Owner'): ?>
              <td>
                <form action="<?php echo e(route('restock.status',$row->id)); ?>" method="post" role="form">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('PATCH')); ?>

                  <input value="1" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
                  <button type="submit" class="label bg-red">Konfirmasi</button>
                </form>
                <?php elseif($row->status == 1 && auth()->user()->level == 'Owner'): ?>
                <span class="label bg-blue">Pengiriman</span>
                <?php elseif($row->status == 0 && auth()->user()->level == 'Purchase'): ?>
                <span class="label bg-red">Belum Terkonfirmasi</span>
                <?php elseif($row->status == 1 && auth()->user()->level == 'Purchase'): ?>
                <span class="label bg-blue">Pengiriman</span>
                <?php elseif($row->status == 0 && auth()->user()->level == 'Admin'): ?>
                <span class="label bg-blue">Proses</span>
                <?php elseif($row->status == 1 && auth()->user()->level == 'Admin'): ?>
                <form action="<?php echo e(route('restock.status',$row->id)); ?>" method="post" role="form">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('PATCH')); ?>

                  <input value="2" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
                  <button type="submit" class="label bg-red">Terima Barang</button>
                </form>
                <?php elseif($row->status == 2 && auth()->user()->level == 'Owner'): ?>
                <span class="label bg-green">Barang diterima</span>
                <?php elseif($row->status == 2 && auth()->user()->level == 'Purchase'): ?>
                <span class="label bg-green">Barang diterima</span>
                <?php elseif($row->status == 2 && auth()->user()->level == 'Admin'): ?>
                <span class="label bg-green">Barang diterima</span>
                <?php endif; ?>
              </td>
              <?php if($row->status == 2): ?>
              <td>
                <form action="<?php echo e(route('restock.stock',$row->id)); ?>" method="post">
                 <?php echo e(csrf_field()); ?>

                 <?php echo e(method_field('PATCH')); ?>

                 <input value="<?php echo e($row->stock); ?>" type="hidden" name="stock" class="form-control" placeholder="Masukkan Kode Inventaris">
                 <input value="<?php echo e($row->quantity); ?>" type="hidden" name="hasil" class="form-control" placeholder="Masukkan Kode Inventaris">
                 <input value="<?php echo e($row->product_name); ?>" type="hidden" name="barang" class="form-control" placeholder="Masukkan Kode Inventaris">
                 <input value="<?php echo e($row->lokasi); ?>" type="hidden" name="lokasi" class="form-control" placeholder="Masukkan Kode lokasi">
                 <input value="3" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
                 <input value="<?php echo e($row->product_price); ?>" type="hidden" name="harga_beli" class="form-control" placeholder="Masukkan Kode Inventaris">
                 <button type="submit" class="btn btn-primary btn-sm" onclick='javascript:return confirm("Apakah anda yakin ingin menghapus data ini?")'><i class="fa fa-plus"></i></button>
               </form>
             </td>
             <td>
              <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('delete')); ?>

              </form>
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
            </td>
            <?php elseif($row->status <= 2): ?>
            <td>
              <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('delete')); ?>

              </form>
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
            </td>
            <?php elseif($row->status = 3): ?>
            <span class="label bg-green">Tersimpan</span>
            <td>
              <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('delete')); ?>

              </form>
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
            </td>
            <?php endif; ?>
          </tr>

          <!-- BASE OWNERR --><!-- BASE OWNERR --><!-- BASE OWNERR --><!-- BASE OWNERR -->
          <?php elseif(auth()->user()->level =='Owner'): ?>
          <tr role="row" class="odd">
            <td><?php echo e($nomor++); ?></td>
            <td><?php echo e($row->name); ?></td>
            <td><?php echo e($row->lokasi); ?></td>
            <td><?php echo e($row->product_name); ?></td>
            <td><?php echo e(rupiah($row->product_price)); ?></td>
            <td><?php echo e($row->quantity); ?> Pcs</td>
            <td><?php echo e(rupiah($row->subtotal)); ?></td>
            <td>
              <?php if($row->status == 0 && auth()->user()->level == 'Owner'): ?>
              <form action="<?php echo e(route('restock.status',$row->id)); ?>" method="post" role="form">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PATCH')); ?>

                <input value="1" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
                <button type="submit" class="label bg-red">Konfirmasi</button>
              </form>
              <?php elseif($row->status == 1 && auth()->user()->level == 'Owner'): ?>
              <span class="label bg-blue">Pengiriman</span>
              <?php elseif($row->status == 0 && auth()->user()->level == 'Purchase'): ?>
              <span class="label bg-red">Belum Terkonfirmasi</span>
              <?php elseif($row->status == 1 && auth()->user()->level == 'Purchase'): ?>
              <span class="label bg-blue">Pengiriman</span>
              <?php elseif($row->status == 0 && auth()->user()->level == 'Admin'): ?>
              <span class="label bg-blue">Proses</span>
              <?php elseif($row->status == 1 && auth()->user()->level == 'Admin'): ?>
              <form action="<?php echo e(route('restock.status',$row->id)); ?>" method="post" role="form">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PATCH')); ?>

                <input value="2" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
                <button type="submit" class="label bg-red">Terima Barang</button>
              </form>
              <?php elseif($row->status == 2 && auth()->user()->level == 'Owner'): ?>
              <span class="label bg-green">Barang diterima</span>
              <?php elseif($row->status == 2 && auth()->user()->level == 'Purchase'): ?>
              <span class="label bg-green">Barang diterima</span>
              <?php elseif($row->status == 2 && auth()->user()->level == 'Admin'): ?>
              <span class="label bg-green">Barang diterima</span>
              <?php endif; ?>
            </td>

            <td>
              <?php if($row->status == 2): ?>
              <form action="<?php echo e(route('restock.stock',$row->id)); ?>" method="post">
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('PATCH')); ?>

               <input value="<?php echo e($row->stock); ?>" type="hidden" name="stock" class="form-control" placeholder="Masukkan Kode Inventaris">
               <input value="<?php echo e($row->quantity); ?>" type="hidden" name="hasil" class="form-control" placeholder="Masukkan Kode Inventaris">
               <input value="<?php echo e($row->product_name); ?>" type="hidden" name="barang" class="form-control" placeholder="Masukkan Kode Inventaris">
               <input value="<?php echo e($row->lokasi); ?>" type="hidden" name="lokasi" class="form-control" placeholder="Masukkan Kode lokasi">
               <input value="3" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
               <input value="<?php echo e($row->product_price); ?>" type="hidden" name="harga_beli" class="form-control" placeholder="Masukkan Kode Inventaris">
               <button type="submit" class="btn btn-primary btn-sm" onclick='javascript:return confirm("Apakah anda yakin ingin menghapus data ini?")'><i class="fa fa-plus"></i></button>
             </form>
           </td>
           <td>
            <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('delete')); ?>

            </form>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
          </td>
          <?php elseif($row->status <= 2): ?>
          <td>
            <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('delete')); ?>

            </form>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
          </td>
          <?php elseif($row->status = 3): ?>
          <span class="label bg-green">Tersimpan</span>
          <td>
            <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('delete')); ?>

            </form>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
          </td>
          <?php endif; ?>
        </tr>

        <!-- BASE PURCAHSE --><!-- BASE PURCAHSE --><!-- BASE PURCAHSE --><!-- BASE PURCAHSE -->
        <?php elseif(auth()->user()->level =='Purchase'): ?>
        <?php $__currentLoopData = $role_cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($teling->user_id) == (auth()->user()->id)): ?>
        <?php if(($row->lokasi) == ($teling->nama_cabang)): ?>
        <tr role="row" class="odd">
          <td><?php echo e($nomor++); ?></td>
          <td><?php echo e($row->name); ?></td>
          <td><?php echo e($row->lokasi); ?></td>
          <td><?php echo e($row->product_name); ?></td>
          <td><?php echo e(rupiah($row->product_price)); ?></td>
          <td><?php echo e($row->quantity); ?> Pcs</td>
          <td><?php echo e(rupiah($row->subtotal)); ?></td>
          <td>
            <?php if($row->status == 0 && auth()->user()->level == 'Owner'): ?>
            <form action="<?php echo e(route('restock.status',$row->id)); ?>" method="post" role="form">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PATCH')); ?>

              <input value="1" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
              <button type="submit" class="label bg-red">Konfirmasi</button>
            </form>
            <?php elseif($row->status == 1 && auth()->user()->level == 'Owner'): ?>
            <span class="label bg-blue">Pengiriman</span>
            <?php elseif($row->status == 0 && auth()->user()->level == 'Purchase'): ?>
            <span class="label bg-red">Belum Terkonfirmasi</span>
            <?php elseif($row->status == 1 && auth()->user()->level == 'Purchase'): ?>
            <span class="label bg-blue">Pengiriman</span>
            <?php elseif($row->status == 0 && auth()->user()->level == 'Admin'): ?>
            <span class="label bg-blue">Proses</span>
            <?php elseif($row->status == 1 && auth()->user()->level == 'Admin'): ?>
            <form action="<?php echo e(route('restock.status',$row->id)); ?>" method="post" role="form">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('PATCH')); ?>

              <input value="2" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
              <button type="submit" class="label bg-red">Terima Barang</button>
            </form>
            <?php elseif($row->status == 2 && auth()->user()->level == 'Owner'): ?>
            <span class="label bg-green">Barang diterima</span>
            <?php elseif($row->status == 2 && auth()->user()->level == 'Purchase'): ?>
            <span class="label bg-green">Barang diterima</span>
            <?php elseif($row->status == 2 && auth()->user()->level == 'Admin'): ?>
            <span class="label bg-green">Barang diterima</span>
            <?php endif; ?>
          </td>
          <?php if($row->status == 2): ?>
          <td>
            <form action="<?php echo e(route('restock.stock',$row->id)); ?>" method="post">
             <?php echo e(csrf_field()); ?>

             <?php echo e(method_field('PATCH')); ?>

             <input value="<?php echo e($row->stock); ?>" type="hidden" name="stock" class="form-control" placeholder="Masukkan Kode Inventaris">
             <input value="<?php echo e($row->quantity); ?>" type="hidden" name="hasil" class="form-control" placeholder="Masukkan Kode Inventaris">
             <input value="<?php echo e($row->product_name); ?>" type="hidden" name="barang" class="form-control" placeholder="Masukkan Kode Inventaris">
             <input value="<?php echo e($row->lokasi); ?>" type="hidden" name="lokasi" class="form-control" placeholder="Masukkan Kode lokasi">
             <input value="3" type="hidden" name="status" class="form-control" placeholder="Masukkan Kode Inventaris">
             <input value="<?php echo e($row->product_price); ?>" type="hidden" name="harga_beli" class="form-control" placeholder="Masukkan Kode Inventaris">
             <button type="submit" class="btn btn-primary btn-sm" onclick='javascript:return confirm("Apakah anda yakin ingin menghapus data ini?")'><i class="fa fa-plus"></i></button>
           </form>
         </td>
         <td>
          <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('delete')); ?>

          </form>
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
        </td>
        <?php elseif($row->status <= 2): ?>
        <td></td>
        <td>
          <form action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger btn-sm" onclick='javascript:return confirm("Apakah anda yakin ingin menghapus data ini?")'><i class="fa fa-trash"></i></button>
          </form>
        </td>
        <?php elseif($row->status = 3): ?>
        <span class="label bg-green">Tersimpan</span>
        <td>
          <form action="<?php echo e(route('restock.destroy',$row->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger btn-sm" onclick='javascript:return confirm("Apakah anda yakin ingin menghapus data ini?")'><i class="fa fa-trash"></i></button>
          </form>
        </td>
        <?php endif; ?>
      </tr>
      <?php endif; ?>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

  </table>
</div>
</div>
</div>
</div>


<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.6.10/vue.min.js"></script>
<script type="text/javascript">
  new Vue({
    el: '#app',
    data: {
      orders: [
      {pesanan: 0, nama: "", harga: 0, jumlah: 1, jumlah2: 1, subtotal: 0},
      ],
      discount: 0,
    },
    methods: {
      addOrder(){
        var orders = {pesanan: 0, nama: "", harga: 0, jumlah: 1, jumlah2: 1, subtotal: 0};
        this.orders.push(orders);
      },
      delOrder(index){
        if (index > 0){
          this.orders.splice(index,1);
        }
      },
      subtotal( jumlah2, jumlah, index){
        var subtotal  = jumlah2*jumlah;
        this.orders[index].subtotal = subtotal;
        return subtotal;
      },
      rupiah(total){
        let val = (total/1).toFixed(2).replace('.', ',')
        return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
      },
      product_name(pesanan, index){
        var product_name = this.nama[pesanan];
        this.orders[index].nama = product_name;
        return product_name;
      },
      product_price(pesanan, index){
        var product_price = this.produk[pesanan];
        this.orders[index].harga = product_price;
        return product_price;
      },
    },
    computed: {
      produk(){
        let produk  = [];
        produk[0] = 0;
        <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        produk[<?php echo e($produk->id); ?>]  = <?php echo e($produk->price); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        return produk;
      },
      nama(){
        let produk  = [];
        produk[0] = 0;
        <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        produk[<?php echo e($produk->id); ?>]  = "<?php echo e($produk->name); ?>"
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        return produk;
      },
      total(){
        var total = this.orders
        .map(order=>order.subtotal)
        .reduce((prev, next)=>prev+next);
        return total - (total * this.discount / 100);
      },
    }
  });
</script>
<script type="text/javascript">
  var rupiah = document.getElementById('rupiah');
  rupiah.addEventListener('keyup', function(e){
      // tambahkan 'Rp.' pada saat form di ketik
      // gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
      rupiah.value = formatRupiah(this.value, 'Rp. ');
    });

  /* Fungsi formatRupiah */
  function formatRupiah(angka, prefix){
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split       = number_string.split(','),
    sisa        = split[0].length % 3,
    rupiah        = split[0].substr(0, sisa),
    ribuan        = split[0].substr(sisa).match(/\d{3}/gi);

      // tambahkan titik jika yang di input sudah menjadi angka ribuan
      if(ribuan){
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
      }

      rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
      return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
  </script>
  <script type="text/javascript">
    $(document).ready( function () {
      $('#table_id').DataTable();
    } );
  </script>

  <?php $__env->stopSection(); ?>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/restock/index.blade.php ENDPATH**/ ?>