<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Akses extends Model
{
	protected $table    = 'role';
}
