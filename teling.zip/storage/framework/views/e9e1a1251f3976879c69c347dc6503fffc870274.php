
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="card ">
  <div class="card-header ">
    <h4 class="card-title"><?php echo e($title); ?></h4>
  </div>
  <div class="card-body ">
    <form method="post" action="" class="form-horizontal">
      <div class="row">
        <label class="col-md-3 col-form-label">Nama</label>
        <div class="col-md-9">
          <div class="form-group">
            <input type="text" value="<?php echo e($data->name); ?>" class="form-control" required="">
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Email</label>
        <div class="col-md-9">
          <div class="form-group">
            <input type="email" value="<?php echo e($data->email); ?>" class="form-control" required="">
          </div>
        </div>
      </div>

      <div class="row">
        <label class="col-md-3 col-form-label">Password</label>

        <div class="col-md-9">
          <div class="form-group">
            <input type="password" value="<?php echo e($data->password); ?>" class="form-control" readonly="">
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Lokasi</label>
        <div class="col-md-9">
          <div class="form-group has-success">
            <select class="form-control" required="">
              <option value=""> -- Silahkan Pilih Lokasi -- </option>
              <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option class="form-control" value="<?php echo e($row->nama_cabang); ?>"><?php echo e($row->nama_cabang); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Jabatan</label>
        <div class="col-md-9">
          <div class="form-group has-success">
            <select class="form-control" required="">
             <option value=""> -- Silahkan Pilih Jabatan -- </option>
             <option class="form-control" value="Owner">Owner</option>
             <option class="form-control" value="Admin">Admin</option>
             <option class="form-control" value="Purchase">Purchase</option>
           </select>
         </div>
       </div>
     </div>

     <div class="fileinput fileinput-new text-center" data-provides="fileinput">
      <div class="fileinput-preview fileinput-exists thumbnail"></div>
      <div>
        <span class="btn btn-rose btn-round btn-file">
          <span class="fileinput-new">Pilih Gambar</span>
          <input type="file" name="..." / required="">
        </span>
      </div>
    </div>
    <div class="row">
      <label class="col-md-3"></label>
      <div class="col-md-9">
        <div class="form-check">
          <label class="form-check-label">
            <input class="form-check-input" type="checkbox">
            <span class="form-check-sign"></span>
            Ingatkan Saya 
          </label>
        </div>
      </div>
    </div>
  </div>
  <div class="card-footer ">
    <div class="row">
      <label class="col-md-3"></label>
      <div class="col-md-9">
        <button type="reset" class="btn btn-fill btn-danger">Reset</button>
        <button type="submit" class="btn btn-fill btn-success">Daftar</button>
      </div>
    </div>
  </div>
</form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/setting/user/edit.blade.php ENDPATH**/ ?>