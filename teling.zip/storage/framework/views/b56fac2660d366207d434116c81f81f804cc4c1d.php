
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"><?php echo e($title); ?></h4>
                <!-- Example split danger button -->
                <div  class="btn-group">
                   <a href="<?php echo e(route('order.create')); ?>"><button type="button" class="btn btn-success"><i class="now-ui-icons ui-1_simple-add"></i> Tambah</button></a>
                   <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="sr-only">Toggle Dropdown</span>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="toolbar">
            </div>
            <table id="table-datatables" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nomor Pelanggan</th>
                        <th>Nama Pelanggan</th>
                        <th>Kasir</th>
                        <th>Cabang</th>
                        <th class="disabled-sorting text-right">Actions</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Nomor Pelanggan</th>
                        <th>Nama Pelanggan</th>
                        <th>Kasir</th>
                        <th>Cabang</th>
                        <th class="disabled-sorting text-right">Actions</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php
                    $nomor = 1;
                    function rupiah($m)
                    {
                        $rupiah = "Rp ".number_format($m,0,",",".").",-";
                        return $rupiah;
                    }
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($row->payment_id != '3'): ?>
                    <tr>
                        <td><?php echo e($nomor++); ?></td>
                        <td><?php echo e($row->table_number); ?></td>
                        <td><?php echo e($row->name); ?></td>
                        <td><?php echo e($row->user->name); ?></td>
                        <td><?php echo e($row->lokasi); ?></td>
                        <td class="text-right">
                            <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('order.destroy',$row->id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('delete')); ?>

                            </form>
                            <?php echo $__env->make('backend.admin.order.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <a href="<?php echo e(url('admin/order/'.$row->id.'/edit')); ?>" data-toggle="modal" data-target="#modal-edit<?php echo e($row->id); ?>"  class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-heart"></i></a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/order/index.blade.php ENDPATH**/ ?>