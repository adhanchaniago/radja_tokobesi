
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"><?php echo e($title); ?></h4>
                <!-- Example split danger button -->
                <div  class="btn-group">
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Separated link</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="toolbar">
            </div>
            <table id="table-datatables" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nomor Meja</th>
                        <th>Pembayaran</th>
                        <th>Kasir</th>
                        <th>Cabang</th>
                        <th>Total</th>
                        <th class="disabled-sorting text-right">Actions</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Nomor Meja</th>
                        <th>Pembayaran</th>
                        <th>Kasir</th>
                        <th>Cabang</th>
                        <th>Total</th>
                        <th class="disabled-sorting text-right">Actions</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php
                    $nomor = 1;
                    function rupiah($m)
                    {
                        $rupiah = "Rp ".number_format($m,0,",",".").",-";
                        return $rupiah;
                    }
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($row->payment_id != '3'): ?>
                    <tr>
                     <td><?php echo e($nomor++); ?></td>
                     <td><?php echo e($row->table_number); ?></td>
                     <td><?php echo e($row->payment->name); ?></td>
                     <td><?php echo e($row->user->name); ?></td>
                     <td><?php echo e($row->lokasi); ?></td>
                     <td><?php echo e(rupiah($row->total)); ?></td>
                     <td class="text-center">
                        <?php echo $__env->make('backend.admin.order.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <a href="<?php echo e(url('admin/order/'.$row->id.'/edit')); ?>" data-toggle="modal" data-target="#modal-edit<?php echo e($row->id); ?>"  class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-heart"></i></a>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/report/index.blade.php ENDPATH**/ ?>