
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="card ">
	<div class="card-header ">
		<h4 class="card-title">Menu Pengguna</h4>
	</div>
	<form name="myform" method="get" action="/" class="form-horizontal">
		<div class="card-body ">
			<div class="row">
				<label class="col-sm-2 col-form-label">Nama Pengguna</label>

				<div class="col-sm-8">
					<div class="form-group has-success">
						<select class="form-control">
							<option value="">-- Pilih Nama Pengguna --</option>
							<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?> (<?php echo e($row->level); ?>)</option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
			</div>
			<div class="row">	
				<label class="col-sm-2 col-form-label">Menu</label>

				<div class="col-sm-4 col-sm-offset-1 checkbox-radios">
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Beranda
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Management
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Supplier
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Kategori
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Kas
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Stock
						</label>
					</div>
				</div>
				<div class="col-sm-4 col-sm-offset-1 checkbox-radios">
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Produk
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Order 
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Pembayaran
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Laporan
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses Cabang
						</label>
					</div>
					<div class="form-check">
						<label class="form-check-label">
							<input id="check_list" class="form-check-input" type="checkbox">
							<span class="form-check-sign"></span>
							Akses User
						</label>
					</div>
				</div>

			</div>
		</div>
		<div class="card-footer ">
			<button type="reset" class="btn btn-fill btn-danger">Reset</button>
			<input style="float: right;" id="Check_All" type="button" value="Check All"
			onClick="Check(document.myform.check_list)" class="btn btn-fill btn-success"></input>
			<button type="submit" class="btn btn-fill btn-primary">Submit</button>
		</div>
	</form>
</div>
<div class="card ">
	<div class="card-header ">
		<h4 class="card-title">Purchase Cabang</h4>
	</div>
	<form method="get" action="/" class="form-horizontal">
		<div class="card-body ">
			<div class="row">
				<label class="col-sm-2 col-form-label">Nama Pengguna</label>
				<div class="col-sm-8">
					<div class="form-group has-success">
						<select class="form-control">
							<option value="">-- Pilih Nama Pengguna --</option>
							<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($row->level == 'Purchase'): ?>
							<option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?> (<?php echo e($row->level); ?>)</option>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
			</div>
			<div class="row">
				<label class="col-sm-2 col-form-label">Cabang</label>
				<div class="col-sm-4 col-sm-offset-1 checkbox-radios">
					<?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="form-check">
						<label class="form-check-label">
							<input class="form-check-input" type="checkbox">
							<span class="form-check-sign"><?php echo e($row->nama_cabang); ?></span>
						</label>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
		<div class="card-footer ">
			<button type="reset" class="btn btn-fill btn-danger">Reset</button>
			<button type="submit" class="btn btn-fill btn-primary">Submit</button>

		</div>
	</form>
</div>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	function Check(chk)
	{
		if(document.myform.Check_All.value=="Check All"){
			for (i = 0; i < chk.length; i++)
				chk[i].checked = true ;
			document.myform.Check_All.value="Uncheck All";
		}else{

			for (i = 0; i < chk.length; i++)
				chk[i].checked = false ;
			document.myform.Check_All.value="Check All";
		}
	}
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/akses/index.blade.php ENDPATH**/ ?>