@extends('layout.main')
@section('title', $title)
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">{{$title}}</h4>
                <!-- Example split danger button -->
                <div  class="btn-group">
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#">Separated link</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="toolbar">
            </div>
            <table id="table-datatables" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nomor Meja</th>
                        <th>Pembayaran</th>
                        <th>Kasir</th>
                        <th>Cabang</th>
                        <th>Total</th>
                        <th class="disabled-sorting text-right">Actions</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Nomor Meja</th>
                        <th>Pembayaran</th>
                        <th>Kasir</th>
                        <th>Cabang</th>
                        <th>Total</th>
                        <th class="disabled-sorting text-right">Actions</th>
                    </tr>
                </tfoot>
                <tbody>
                    @php
                    $nomor = 1;
                    function rupiah($m)
                    {
                        $rupiah = "Rp ".number_format($m,0,",",".").",-";
                        return $rupiah;
                    }
                    @endphp
                    @foreach ($data as $row)
                    @if ($row->payment_id != '3')
                    <tr>
                     <td>{{$nomor++}}</td>
                     <td>{{$row->table_number}}</td>
                     <td>{{$row->payment->name}}</td>
                     <td>{{$row->user->name}}</td>
                     <td>{{$row->lokasi}}</td>
                     <td>{{rupiah($row->total)}}</td>
                     <td class="text-center">
                        @include('backend.admin.order.modal')
                        <a href="{{url('admin/order/'.$row->id.'/edit')}}" data-toggle="modal" data-target="#modal-edit{{$row->id}}"  class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-heart"></i></a>
                    </td>
                </tr>
                @endif
                @endforeach
            </tbody>
        </table>
    </div>
</div>
</div>
</div>
@endsection
