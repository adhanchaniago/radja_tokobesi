@extends('layout.main')
@section('title', $title)
@section('content')
<div class="row">
  <div class="col-md-12">
    <div class="card ">
      <div class="card-header ">
        <h4 class="card-title">Input Pengeluaran</h4>
      </div>
      <div class="card-body ">
        <form method="post" method="post" action="{{route('credit.store')}}" enctype="multipart/form-data" class="form-horizontal">
          @csrf
          <div class="row">
            <label class="col-md-3 col-form-label">Penanggung Jawab</label>
            <div class="col-md-9">
              <div class="form-group">
                <input type="text" name="name" value="{{auth()->user()->name}}" class="form-control" readonly="">
                <input type="hidden" name="table_number" class="form-control" value="1" id="inputNama" placeholder="ex: 12">
              </div>
            </div>
          </div>
          <div class="row">
            <label class="col-md-3 col-form-label">Jenis Penerimaan</label>
            <div class="col-md-9">
              <div class="form-group">
               <select class="form-control" name="payment_id">
                <option value="">-- Pilih Terima --</option>
                @foreach ($pay as $row)
                @if ($row->status)
                <option value="{{$row->id}}">{{$row->name}}</option>
                @endif
                @endforeach
              </select>
            </div>
          </div>
        </div>
        <div class="row">
          <label class="col-md-3 col-form-label">Keperluan</label>
          <div class="col-md-9">
            <div class="form-group">
             <select class="form-control" name="keperluan">
              <option value="">-- Pilih Keperluan --</option>
              <option value="Fasilitas">Fasilitas</option>
              <option value="Inventaris">Inventaris</option>
              <option value="Komisi">Komisi</option>
              <option value="Beli">Beli</option>
              <option value="Saham">Saham</option>
            </select>
          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Nominal</label>
        <div class="col-md-9">
          <div class="form-group">
            <input type="text" name="total" class="form-control" id="inputKredit" placeholder="Masukkan Rupiah">
            <input type="hidden" name="created_by" value="{{auth()->user()->id}}" class="form-control" >

          </div>
        </div>
      </div>
      <div class="row">
        <label class="col-md-3 col-form-label">Bukti</label>
        <div class="col-md-9">
          <div class="form-group">
            <span class="btn btn-rose btn-round btn-file">
              <span class="fileinput-new">Pilih Gambar</span>
              <input type="file" name="image" id="image" required="">
            </span>
          </div>

        </div>
      </div>

    </div>
    <div class="card-footer ">
      <div class="row">
        <label class="col-md-3"></label>
        <div class="col-md-9">
          <button type="reset" class="btn btn-fill btn-danger">Reset</button>
          <button type="submit" class="btn btn-fill btn-success">Masuk</button>
        </div>
      </div>
    </div>
  </form>
</div>
</div></div>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">{{$title}}</h4>
        <!-- Example split danger button -->
        
      </div>
      <div class="card-body">
        <div class="toolbar">
        </div>
        <table id="table-datatables" class="table table-striped table-bordered" cellspacing="0" width="100%">
          <thead style="font-size: 10px; ">
            <tr>
              <th>No</th>
              <th>Penanggung Jawab</th>
              <th>Pembayaran</th>
              <th>Keperluan</th>
              <th>Uang Masuk</th>
              <th>Uang Keluar</th>
              <th>Cabang</th>
              <th>Saldo</th>
              <th class="disabled-sorting text-right">Actions</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Penanggung Jawab</th>
              <th>Pembayaran</th>
              <th>Keperluan</th>
              <th>Uang Masuk</th>
              <th>Uang Keluar</th>
              <th>Cabang</th>
              <th>Saldo</th>
              <th class="disabled-sorting text-right">Actions</th>
            </tr>
          </tfoot>
          <tbody>
            @php
            $nomor = 1;
            function rupiah($m)
            {
              $rupiah = "Rp ".number_format($m,0,",",".").",-";
              return $rupiah;
            }
            @endphp
            @foreach ($data as $row)
            <tr>
             <td>{{$nomor++}}</td>
             <td>{{$row->name}}</td>
             <td>{{$row->payment->name}}</td>
             <td>{{$row->keperluan}}</td>
             @if ($row->payment->name!='Kredit')
             <td>{{rupiah($row->total)}}</td>
             @endif
             <td>
               @if  ($row->payment->name=='Kredit')
               <td>{{rupiah($row->total)}}</td>
               @endif
             </td>
             <td>{{$row->lokasi}}</td>
             <td>{{rupiah($row->total)}}</td>
             <td class="text-center">
              @if ($row->payment->name!='Kredit')
              @include('backend.admin.order.modal')
              <a href="{{url('admin/order/'.$row->id.'/edit')}}" data-toggle="modal" data-target="#modal-edit{{$row->id}}"  class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-heart"></i></a>
              @else
              @include('backend.admin.kas.modal')
              <a href="{{url('admin/kas/'.$row->id.'/edit')}}" data-toggle="modal" data-target="#modal-edit{{$row->id}}"  class="btn btn-round btn-primary btn-icon btn-sm like"><i class="fas fa-file"></i></a>
              @endif
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>
@endsection
