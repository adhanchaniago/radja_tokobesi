@extends('layout.main')
@section('title', $title)
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">{{$title}}</h4>
                <!-- Example split danger button -->
                <div  class="btn-group">
                 <a href="{{route('item.create')}}"><button type="button" class="btn btn-success"><i class="now-ui-icons ui-1_simple-add"></i> Tambah</button></a>
                 <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="sr-only">Toggle Dropdown</span>
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Import CSV</a>
                    
                </div>
            </div>
        </div>
        <div class="card-body filterable">
            <div class="toolbar">
            </div>
            <table id="table-datatables" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Cabang Toko</th>
                        <th>Merk</th>
                        <th>Harga Beli</th>
                        <th>Harga Jual</th>
                        <th>Stock</th>
                        <th>Stock Minim</th>
                        <th width="12%" class="disabled-sorting text-center">Actions</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr class="filters">
                        <th>#</th>
                        <th><input type="text" class="form-control" placeholder="Nama" disabled></th>
                        <th><input type="text" class="form-control" placeholder="Cabang Toko" disabled></th>
                        <th><input type="text" class="form-control" placeholder="Merk" disabled></th>
                        <th><input type="text" class="form-control" placeholder="Harga Beli" disabled></th>
                        <th><input type="text" class="form-control" placeholder="Harga Jual" disabled></th>
                        <th><input type="text" class="form-control" placeholder="Stock" disabled></th>
                        <th><input type="text" class="form-control" placeholder="Stock Minim" disabled></th>
                        <th><button class="btn btn-default btn-xs btn-filter"><span class="fa fa-filter"></span> Filter</button></th>
                    </tr>
                </tfoot>
                <tbody>
                    @php
                    $nomor = 1;
                    function rupiah($m)
                    {
                        $rupiah = "Rp ".number_format($m,0,",",".").",-";
                        return $rupiah;
                    }
                    @endphp
                    @foreach ($data as $row)
                    <tr>
                        <td>{{$nomor++}}</td>
                        <td>{{$row->name}}</td>
                        <td>{{$row->lokasi}}</td>
                        <td>{{$row->merk}}</td>
                        <td>{{rupiah($row->purchase_price)}}</td>
                        @if($row->price > $row->purchase_price)
                        <td>{{rupiah($row->price)}}</td>
                        @else
                        <td><span class="label bg-red"><b>{{rupiah($row->price)}}</b></span></td>
                        @endif
                        <td>
                          @if ($row->stock >= $row->stock_minim )
                          {{$row->stock}} Pcs
                          @else 
                          <a href="{{url('admin/restock')}}"><span class="label bg-red">Restock</span></a>
                          @endif
                      </td>
                      <td>
                       {{$row->stock_minim}} Pcs
                   </td>
                   <td class="text-right">
                     <form id="data-{{ $row->id }}" action="{{route('item.destroy',$row->id)}}" method="post">
                        {{csrf_field()}}
                        {{method_field('delete')}}
                    </form>
                    @include('backend.admin.produk.modal')
                    <a href="{{url('admin/produk/'.$row->id.'/edit')}}" data-toggle="modal" data-target="#modal-edit{{$row->id}}"  class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-heart"></i></a>
                    <a href="{{url('admin/item/'.$row->id.'/edit')}}"  class="btn btn-round btn-warning btn-icon btn-sm edit"><i class="far fa-calendar-alt"></i></a>
                    @csrf
                    @method('DELETE')
                    <button type="submit" onclick="deleteRow( {{ $row->id }} )" class="btn btn-round btn-danger btn-icon btn-sm remove"><i class="fas fa-times"></i></button>
                </td>
            </tr>
            @endforeach
            
        </tbody>
        <tr>
            @foreach ($data as $row)
            <td colspan="4" class="text-center">Total</td>
            <td>{{rupiah($row->sum('purchase_price'))}}</td>
            <td>{{rupiah($row->sum('price'))}}</td>
            <td>{{$row->sum('stock')}} Pcs</td>
            <td>{{$row->sum('stock_minim')}} Pcs</td><td class="text-center">#</td>
            @endforeach
            
        </tr>
    </table>

</div>
</div>
</div>
</div>
@section('script')
<script type="text/javascript">

    $(document).ready(function(){
        $('.filterable .btn-filter').click(function(){
            var $panel = $(this).parents('.filterable'),
            $filters = $panel.find('.filters input'),
            $tbody = $panel.find('.table tbody');
            if ($filters.prop('disabled') == true) {
                $filters.prop('disabled', false);
                $filters.first().focus();
            } else {
                $filters.val('').prop('disabled', true);
                $tbody.find('.no-result').remove();
                $tbody.find('tr').show();
            }
        });

        $('.filterable .filters input').keyup(function(e){
            /* Ignore tab key */
            var code = e.keyCode || e.which;
            if (code == '9') return;
            /* Useful DOM data and selectors */
            var $input = $(this),
            inputContent = $input.val().toLowerCase(),
            $panel = $input.parents('.filterable'),
            column = $panel.find('.filters th').index($input.parents('th')),
            $table = $panel.find('.table'),
            $rows = $table.find('tbody tr');
            /* Dirtiest filter function ever ;) */
            var $filteredRows = $rows.filter(function(){
                var value = $(this).find('td').eq(column).text().toLowerCase();
                return value.indexOf(inputContent) === -1;
            });
            /* Clean previous no-result if exist */
            $table.find('tbody .no-result').remove();
            /* Show all rows, hide filtered ones (never do that outside of a demo ! xD) */
            $rows.show();
            $filteredRows.hide();
            /* Prepend no-result row if all rows are filtered */
            if ($filteredRows.length === $rows.length) {
                $table.find('tbody').prepend($('<tr class="no-result text-center"><td colspan="'+ $table.find('.filters th').length +'">No result found</td></tr>'));
            }
        });
    });
</script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
@include('sweet::alert')
@endsection
@endsection
