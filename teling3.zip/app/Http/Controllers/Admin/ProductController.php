<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ProductImport;
use App\Http\Controllers\Controller;
use App\Model\Product;
use App\Model\Restock;
use App\Model\Category;
use App\Model\Cabang;
use App\Exports\OrdersExport;
use App\Jobs\ImportJob;
use PDF;
use DB;
use Alert;

class ProductController extends Controller
{
    private $titlePage='Produk';
    private $titlePage2='Tambah Produk';
    private $titlePage3='Update Produk';

    protected $folder   = 'backend.admin.produk';
    protected $rdr   = 'admin/item';
    public function index()
    {
        $params=[
            'title' => $this->titlePage
        ];
        $data   = Product::all();
        $role  = DB::table('role')
        ->join('users', 'role.user_id', '=', 'users.id')
        ->get();
        return view($this->folder.'.index',$params, compact('data', 'role'));
    }
    public function create()
    {
        $params=[
            'title' => $this->titlePage
        ];
        $data   = Category::all();
        $stock = Restock::all();
        $cabang = Cabang::all();
        $role  = DB::table('role')
        ->join('users', 'role.user_id', '=', 'users.id')
        ->get();
        return view($this->folder.'.create',$params, compact('data', 'role', 'cabang'));
    }
    public function store(Request $request)
    {
        $data   = new Product;
        $data->category_id  = $request->category;
        $data->name  = $request->name;
        $data->lokasi  = $request->nama_cabang;
        $data->price  = $request->price;
        $data->purchase_price  = $request->purchase_price;
        $data->status  = $request->status;
        $data->merk  = $request->merk;
        $data->stock  = $request->stock;
        $data->satuan  = $request->satuan;
        $data->stock_minim  = $request->stock_minim;
        $data->save();
        return redirect($this->rdr)->with('success', 'Data berhasil ditambahkan');
    }
    public function edit($id)
    {
        $params=[
            'title' => $this->titlePage3
        ];
        $cat  = Category::all();
        $data = Product::find($id);
        $cabang = Cabang::all();
        $role  = DB::table('role')
        ->join('users', 'role.user_id', '=', 'users.id')
        ->get();
        return view($this->folder.'.edit',$params, compact('data','cat', 'role', 'cabang'));
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'category'  => 'required',
            'name'  => 'required',
            'price'  => 'required',
            'status'  => 'required',
        ]);
        Product::find($id)->update(
            [
                'category_id'   => $request->category,
                'name'   => $request->name,
                'merk'   => $request->merk,
                'lokasi'   => $request->nama_cabang,
                'purchase_price'   => $request->purchase_price,
                'price'   => $request->price,
                'status'   => $request->status,
                'satuan'   => $request->satuan,
                'stock'   => $request->stock,
                'stock_minim'   => $request->stock_minim,
            ]
        );
        return redirect($this->rdr)->with('success', 'Data berhasil di ubah');
    }
    public function destroy($id)
    {
        $data   = Product::find($id);
        $data->delete();
        return redirect($this->rdr)->with('success', 'Data berhasil di Hapus');
    }

    // base print
    public function download(Request $request)
    {
        $tipe   = $request->get('tipe');
        if ($tipe == null) {
            return redirect()->back()->with('failed', 'Data tidak ada');
        }elseif ($tipe == 1) {
            return $this->pdf($request);
        }else{
            return $this->excel($request);
        }
    }
    public function pdf(Request $request)
    {
        $product  = Product::all();
        $pdf    = PDF::loadView('admin.product.item.pdf',  compact('product'));    
        return $pdf->download('item.pdf');

    }
    // request barang 
    public function barang_masuk()
    {
        $data   = Product::all();
        $role  = DB::table('role')
        ->join('users', 'role.user_id', '=', 'users.id')
        ->get();
        return view($this->folder.'.index',compact('data', 'role'));
    }
    public function import(Request $request)
    {
        Excel::import(new ProductImport,request()->file('file'));
        return back()->with('success', 'Import CSV Suskses!!!');
    }
}
