
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"><?php echo e($title); ?></h4>
        <!-- Example split danger button -->
        <div  class="btn-group">
        </button>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Separated link</a>
        </div>
      </div>
    </div>
    <div class="card-body">
      <div class="toolbar">
      </div>
      <table id="table-datatables" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
          <tr>
            <th>No</th>
            <th>Nomor Meja</th>
            <th>Pembayaran</th>
            <th>Kasir</th>
            <!-- <th>Cabang</th> -->
            <th>Total</th>
            <th>Tanggal</th>
            <th class="disabled-sorting text-right">Actions</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            <th colspan="4" class="text-center">Total</th>
            <!-- <th>Cabang</th> -->
            <th>Total</th>
            <th>Tanggal</th>
            <th class="disabled-sorting text-center">Actions</th>
          </tr>
        </tfoot>
        <tbody>
          <?php
          $nomor = 1;
          function rupiah($m)
          {
            $rupiah = "Rp ".number_format($m,0,",",".");
            return $rupiah;
          }
          ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($row->keperluan == 'Penjualan'): ?>
          <tr>
           <td><?php echo e($nomor++); ?></td>
           <td><?php echo e($row->table_number); ?></td>
           <td><?php echo e($row->payment->name); ?></td>
           <td><?php echo e($row->user->name); ?></td>
           <!-- <td><?php echo e($row->lokasi); ?></td> -->
           <td>Rp <?php echo e($row->total); ?></td>
           <td><?php echo e($row->created_at); ?></td>
           <td class="text-center">
            <?php echo $__env->make('backend.admin.order.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <a href="<?php echo e(url('admin/order/'.$row->id.'/edit')); ?>" data-toggle="modal" data-target="#modal-edit<?php echo e($row->id); ?>"  class="btn btn-round btn-info btn-icon btn-sm like"><i class="fas fa-heart"></i></a>
          </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
</div>
</div>
<?php $__env->startSection('script'); ?>
<script type="text/javascript"> 
  $(document).ready(function () {
    $('#table-datatables').DataTable({
      dom: 'Bfrtip',
      buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
      "footerCallback": function ( row, data, start, end, display ) {
        var api = this.api(), data;

            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
              return typeof i === 'string' ?
              i.replace(/[\Rp,]/g, '')*1 :
              typeof i === 'number' ?
              i : 0;
            };


            // Total Uang Keluar
            total2 = api
            .column( 4 )
            .data()
            .reduce( function (a, b) {
              return intVal(a) + intVal(b);
            }, 0 );

            // Total over this page
            pageTotal2 = api
            .column( 4, { page: 'current'} )
            .data()
            .reduce( function (a, b) {
              return intVal(a) + intVal(b);
            }, 0 );

            // Update footer
            $( api.column( 4 ).footer() ).html(
              'Rp '+ pageTotal2 
              );


          }
        });
  });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/report/index.blade.php ENDPATH**/ ?>