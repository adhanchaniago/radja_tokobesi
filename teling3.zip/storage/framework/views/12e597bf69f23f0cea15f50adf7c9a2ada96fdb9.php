
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="card ">
  <div class="card-header ">
    <h4 class="card-title"><?php echo e($title); ?></h4>
  </div>
  <div class="card-body ">
    <form method="post" method="post" action="<?php echo e(route('supplier.update', $data->id)); ?>" class="form-horizontal">
     <?php echo csrf_field(); ?>
     <?php echo method_field('PUT'); ?>
     <div class="row">
      <label class="col-md-3 col-form-label">Nama</label>
      <div class="col-md-9">
        <div class="form-group">
          <input type="text" name="nama" value="<?php echo e($data->nama); ?>" class="form-control" required="">
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-md-3 col-form-label">Perusahaan</label>
      <div class="col-md-9">
        <div class="form-group">
          <input type="text" name="perusahaan" value="<?php echo e($data->perusahaan); ?>" class="form-control" required="">
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-md-3 col-form-label">Produk</label>
      <div class="col-md-9">
        <div class="form-group">
          <input type="text" name="produk" value="<?php echo e($data->produk); ?>" class="form-control" required="">
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-md-3 col-form-label">Nomor Telepon</label>
      <div class="col-md-5">
        <div class="form-group">
          <input type="text" name="notelp" value="<?php echo e($data->notelp); ?>" class="form-control" required="">
        </div>
      </div>
    </div>
    <div class="row">
      <label class="col-md-3"></label>
      <div class="col-md-9">
        <div class="form-check">
          <label class="form-check-label">
            <input class="form-check-input" type="checkbox">
            <span class="form-check-sign"></span>
            Ingatkan Saya 
          </label>
        </div>
      </div>
    </div>
  </div>
  <div class="card-footer ">
    <div class="row">
      <label class="col-md-3"></label>
      <div class="col-md-9">
        <button type="reset" class="btn btn-fill btn-danger">Reset</button>
        <button type="submit" class="btn btn-fill btn-success">Masuk</button>
      </div>
    </div>
  </div>
</form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/supplier/edit.blade.php ENDPATH**/ ?>