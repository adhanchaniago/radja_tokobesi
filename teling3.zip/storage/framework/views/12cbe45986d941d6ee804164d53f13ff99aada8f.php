<div style="text-align: center;" class="modal fade" id="modal-edit<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h3><?php echo e($row->nama); ?> (<?php echo e($row->notelp); ?>) </h3>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
          <i class="now-ui-icons ui-1_simple-remove"></i>
        </button>
      </div>
      <div id="#<?php echo e($row->id); ?>" class="modal-body">
        <div class="instruction">
          <div class="row">
            <div class="col-md-12">
             <table class="table table-striped">
              <thead>
                <tr>
                  <th>Nama</th>
                  <th>Perusahaan</th>
                  <th>Produk</th>
                  <th>Dibuat pada</th>
                  <th>Dirubah Pada</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo e($row->nama); ?></td>
                  <td><?php echo e($row->perusahaan); ?></td>
                  <td><?php echo e($row->produk); ?></td>
                  <td><?php echo e(date('d F Y', strtotime($row->created_at))); ?> - <?php echo e(date('H:i', strtotime($row->created_at))); ?> WIB</td>
                  <td><?php echo e(date('d F Y', strtotime($row->updated_at))); ?> - <?php echo e(date('H:i', strtotime($row->updated_at))); ?> WIB</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-footer justify-content-center">
      <a href="<?php echo e(url('admin/supplier/'.$row->id.'/edit')); ?>" class="btn btn-warning btn-icon edit"><i class="far fa-calendar-alt"></i></a>
      <form id="data-<?php echo e($row->id); ?>" action="<?php echo e(route('supplier.destroy',$row->id)); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('delete')); ?>

      </form>
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" onclick="deleteRow( <?php echo e($row->id); ?> )" class="btn btn-round btn-danger btn-icon remove"><i class="fas fa-times"></i></button>
    </div>
  </div>
</div>
</div>

<?php /**PATH D:\RADJA\kasir_online\resources\views/backend/admin/supplier/modal.blade.php ENDPATH**/ ?>